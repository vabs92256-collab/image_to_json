                    +-----------------------+
                    |      Web App          |
                    |  (chatbot/flask)      |
                    +-----------+-----------+
                                |
                                | client 
                                v
                  +---------------------------+
                  |       MCP Server          |
                  |      (FastMCP/Python)     |
                  +-----------+---------------+
                              |
        -------------------------------------------------
        |              |              |                 |
        v              v              v                 v
+---------------+ +--------------+ +--------------+ +----------------+
| OCR Tool      | | Summary Tool | | Translation  | | Table Extractor|
| RapidOCR      | | Llama/Gemma  | |              | | Camelot/Tabula |
+---------------+ +--------------+ +--------------+ +----------------+
        |              |              |                 |
        -----------------------------------------------
                              |
                              v
                    Structured JSON Response






| Component        | Technology                              |
| ---------------- | --------------------------------------- |
| Frontend         | flask / chatbot                         |
| Backend          | FastAPI                                 |
| MCP Framework    | FastMCP                                 |
| OCR              | PaddleOCR or RapidOCR                   |
| LLM              | demini(neev api )                       |
| Translation      | deep translator.                        |
| Table Extraction | PaddleOCR Table                         |
| Deployment       | IIS + FastAPI/Uvicorn                   |



                    User
                      │
        Upload PDF + Ask Question
                      │
                      ▼
            +----------------------+
            |    Flask Chat UI     |
            +----------+-----------+
                       │
                       ▼
             FastAPI + LangGraph
                       │
             Intent Router (Python)
                       │
        ┌──────────────┼──────────────┐
        │              │              │
        ▼              ▼              ▼
     OCR Node     Summary Node   Translation Node
        │              │              │
        └──────────────┼──────────────┘
                       │
                  Table Node
                       │
                       ▼
                  MCP Tool Calls
                       │
                       ▼
                Structured Response
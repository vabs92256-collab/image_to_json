# mcp_client.py
from mcp import ClientSession
from mcp.client.sse import sse_client

class MCPClient:
    def __init__(self, server_url: str):
        self.server_url = server_url # e.g., "http://localhost:8080/sse"

    async def call_tool(self, tool_name: str, arguments: dict):
        # Connect to the remote server via SSE
        async with sse_client(self.server_url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments)
                return result.content[0].text
# mcp_server.py
from mcp.server.fastmcp import FastMCP
from rapidocr_onnxruntime import RapidOCR
import fitz
import base64

# Create the server
mcp = FastMCP("DocumentProcessor", port=8080)
ocr_engine = RapidOCR()

@mcp.tool()
def perform_ocr(pdf_base64: str) -> str:
    """OCR Tool"""
    pdf_data = base64.b64decode(pdf_base64)
    doc = fitz.open(stream=pdf_data, filetype="pdf")
    text_results = []
    for page in doc:
        pix = page.get_pixmap()
        img_bytes = pix.tobytes("png")
        result, _ = ocr_engine(img_bytes)
        if result:
            text_results.append(" ".join([line[1] for line in result]))
    return "\n".join(text_results)

@mcp.tool()
def get_llm_response(ocr_text: str, user_query: str) -> str:
    """Mock LLM Tool"""
    return f"🤖 [SSE REMOTE RESPONSE]\nSummary of your query '{user_query}':\nDocument contains: {ocr_text[:50]}..."

if __name__ == "__main__":
    # This starts a Starlette/FastAPI server specifically for MCP
    mcp.run(transport="sse")
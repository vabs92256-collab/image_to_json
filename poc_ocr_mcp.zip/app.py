# app.py
import os
import base64
from typing import TypedDict, Literal
from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.templating import Jinja2Templates
from langgraph.graph import StateGraph, END
from mcp_client import MCPClient

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Configure remote URL
REMOTE_SERVER_URL = "http://localhost:8080/sse" 
client = MCPClient(REMOTE_SERVER_URL)

class AgentState(TypedDict):
    pdf_base64: str
    user_query: str
    ocr_text: str
    final_response: str

# --- NODES ---
async def ocr_node(state: AgentState):
    text = await client.call_tool("perform_ocr", {"pdf_base64": state["pdf_base64"]})
    return {"ocr_text": text, "final_response": text}

async def llm_node(state: AgentState):
    response = await client.call_tool("get_llm_response", {
        "ocr_text": state["ocr_text"], 
        "user_query": state["user_query"]
    })
    return {"final_response": response}

def router(state: AgentState) -> Literal["llm", "end"]:
    q = state["user_query"].lower()
    return "llm" if "summary" in q or "summarize" in q else "end"

# --- GRAPH ---
workflow = StateGraph(AgentState)
workflow.add_node("ocr", ocr_node)
workflow.add_node("llm", llm_node)
workflow.set_entry_point("ocr")
workflow.add_conditional_edges("ocr", router, {"llm": "llm", "end": END})
workflow.add_edge("llm", END)
graph = workflow.compile()

@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")

@app.post("/process")
async def process(file: UploadFile = File(...), query: str = Form(...)):
    content = await file.read()
    pdf_b64 = base64.b64encode(content).decode('utf-8')
    result = await graph.ainvoke({"pdf_base64": pdf_b64, "user_query": query})
    return {"answer": result["final_response"]}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)